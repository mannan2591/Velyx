export type VoiceStyle = "warm" | "calm" | "bright" | "deep";

export interface VoiceProfile {
  id: string;
  name: string;
  style: VoiceStyle;
  description: string;
}

export type RecorderStatus = "idle" | "recording" | "processing" | "error";

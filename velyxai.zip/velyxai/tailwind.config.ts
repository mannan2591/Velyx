import type { Config } from "tailwindcss";

// VelyxAI design tokens
// Palette: deep aubergine ground, soft violet + lavender signal colors,
// a warm cream for readable surfaces, and a rose-glow reserved for the
// voice/presence orb only — it never appears in static UI chrome.
const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./providers/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ground: {
          DEFAULT: "#160F1E", // deep aubergine — base canvas
          soft: "#1E1527",
          deep: "#0D0812",
        },
        violet: {
          50: "#F3EEFC",
          100: "#E5D9F7",
          200: "#D0BBEF",
          300: "#B79AE6",
          400: "#9B7EDE",
          500: "#8161CE", // primary accent
          600: "#6947AC",
          700: "#4F3384",
        },
        lavender: {
          DEFAULT: "#D9C7F5",
          muted: "#B7A6D6",
        },
        cream: {
          DEFAULT: "#F5EEE3",
          dim: "#E8DFD0",
        },
        glow: {
          rose: "#E7B8C9", // reserved: voice / presence orb only
        },
        muted: {
          DEFAULT: "#9385A8",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-manrope)", "sans-serif"],
        mono: ["var(--font-jetbrains)", "monospace"],
      },
      borderRadius: {
        xl: "1.25rem",
        "2xl": "1.75rem",
        "3xl": "2.5rem",
      },
      boxShadow: {
        glass: "0 8px 40px -8px rgba(13, 8, 18, 0.55)",
        "glow-violet": "0 0 60px -10px rgba(139, 108, 222, 0.45)",
        "glow-rose": "0 0 80px -12px rgba(231, 184, 201, 0.35)",
      },
      backdropBlur: {
        xs: "2px",
      },
      keyframes: {
        breathe: {
          "0%, 100%": { transform: "scale(1)", opacity: "0.9" },
          "50%": { transform: "scale(1.06)", opacity: "1" },
        },
        "drift-slow": {
          "0%": { transform: "translate(0,0)" },
          "50%": { transform: "translate(20px,-30px)" },
          "100%": { transform: "translate(0,0)" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        breathe: "breathe 4.2s ease-in-out infinite",
        "drift-slow": "drift-slow 12s ease-in-out infinite",
        "fade-up": "fade-up 0.7s cubic-bezier(0.16,1,0.3,1) forwards",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;

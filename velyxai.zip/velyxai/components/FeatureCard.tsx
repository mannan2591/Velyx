"use client";

import * as React from "react";
import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { GlassCard } from "./GlassCard";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

export function FeatureCard({ icon: Icon, title, description, index }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -4 }}
    >
      <GlassCard className="group h-full p-6 transition-colors hover:border-violet-300/30">
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-violet-500/15 text-violet-200 transition-colors group-hover:bg-violet-500/25">
          <Icon className="h-5 w-5" strokeWidth={1.75} />
        </div>
        <h3 className="font-display text-lg text-cream">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">{description}</p>
      </GlassCard>
    </motion.div>
  );
}

import Link from "next/link";
import { AssistantAvatar } from "./AssistantAvatar";
import { GradientButton } from "./GradientButton";

const LINKS = [
  { href: "/chat", label: "Chat" },
  { href: "/voice", label: "Voice Studio" },
  { href: "/pricing", label: "Pricing" },
];

export function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ground/70 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-3">
          <AssistantAvatar size="sm" />
          <span className="font-display text-lg tracking-wide text-cream">VelyxAI</span>
        </Link>
        <div className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-sm text-muted transition-colors hover:text-cream"
            >
              {l.label}
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <Link href="/login" className="text-sm text-muted hover:text-cream">
            Log in
          </Link>
          <Link href="/chat">
            <GradientButton className="px-5 py-2 text-xs">Get Started</GradientButton>
          </Link>
        </div>
      </nav>
    </header>
  );
}

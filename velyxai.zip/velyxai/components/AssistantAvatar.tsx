"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface AssistantAvatarProps {
  /** 0-1 live amplitude, drives reactive pulsing (voice mode). Omit for ambient idle breathing. */
  amplitude?: number;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const sizes = {
  sm: "h-10 w-10",
  md: "h-16 w-16",
  lg: "h-40 w-40",
  xl: "h-64 w-64",
};

/**
 * The Presence — VelyxAI's signature element.
 * A softly breathing gradient orb rather than a literal face render.
 * At rest it performs a slow 4.2s breathing cycle; when `amplitude` is
 * provided (Voice Studio) it reacts to live audio energy instead.
 */
export function AssistantAvatar({ amplitude, size = "md", className }: AssistantAvatarProps) {
  const reactive = typeof amplitude === "number";
  const scale = reactive ? 1 + Math.min(amplitude!, 1) * 0.18 : undefined;

  return (
    <div className={cn("relative flex items-center justify-center", sizes[size], className)}>
      {/* outer ambient halo */}
      <motion.div
        className="absolute inset-[-30%] rounded-full opacity-60 blur-2xl"
        style={{
          background:
            "radial-gradient(circle, rgba(231,184,201,0.35) 0%, rgba(155,126,222,0.25) 45%, transparent 70%)",
        }}
        animate={reactive ? { scale: 1 + Math.min(amplitude!, 1) * 0.4 } : { scale: [1, 1.15, 1] }}
        transition={reactive ? { duration: 0.12 } : { duration: 4.2, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* core orb */}
      <motion.div
        className="relative h-full w-full rounded-full"
        style={{
          background:
            "radial-gradient(circle at 32% 28%, #F5EEE3 0%, #D9C7F5 22%, #9B7EDE 55%, #4F3384 100%)",
          boxShadow: "0 0 40px rgba(155,126,222,0.5), inset 0 0 30px rgba(255,255,255,0.15)",
        }}
        animate={reactive ? { scale } : { scale: [1, 1.06, 1], opacity: [0.9, 1, 0.9] }}
        transition={reactive ? { duration: 0.12 } : { duration: 4.2, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* specular ring */}
      <div className="absolute inset-0 rounded-full border border-white/20" />
    </div>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface VoiceVisualizerProps {
  levels: number[]; // 0-1 values, one per bar
  active?: boolean;
  className?: string;
}

/** Bar-style waveform driven by an array of amplitude levels (0-1). */
export function VoiceVisualizer({ levels, active, className }: VoiceVisualizerProps) {
  return (
    <div className={cn("flex h-16 items-center justify-center gap-1", className)}>
      {levels.map((level, i) => (
        <motion.span
          key={i}
          className="w-1 rounded-full bg-gradient-to-t from-violet-500 to-lavender"
          animate={{ height: active ? `${8 + level * 56}px` : "6px", opacity: active ? 1 : 0.4 }}
          transition={{ duration: 0.09, ease: "easeOut" }}
        />
      ))}
    </div>
  );
}

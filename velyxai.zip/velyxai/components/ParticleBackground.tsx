"use client";

import * as React from "react";

interface Orb {
  id: number;
  size: number;
  top: string;
  left: string;
  duration: number;
  delay: number;
  hue: "violet" | "rose" | "cream";
}

const HUES: Record<Orb["hue"], string> = {
  violet: "rgba(155,126,222,0.28)",
  rose: "rgba(231,184,201,0.22)",
  cream: "rgba(245,238,227,0.10)",
};

function generateOrbs(count: number): Orb[] {
  const hues: Orb["hue"][] = ["violet", "rose", "cream"];
  return Array.from({ length: count }).map((_, i) => ({
    id: i,
    size: 120 + ((i * 47) % 220),
    top: `${(i * 23) % 90}%`,
    left: `${(i * 61) % 90}%`,
    duration: 10 + (i % 6) * 2,
    delay: (i % 5) * 0.8,
    hue: hues[i % hues.length],
  }));
}

/** Soft ambient floating gradient orbs — decorative, aria-hidden. */
export function ParticleBackground({ count = 8 }: { count?: number }) {
  const orbs = React.useMemo(() => generateOrbs(count), [count]);

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {orbs.map((orb) => (
        <div
          key={orb.id}
          className="absolute rounded-full blur-3xl animate-drift-slow"
          style={{
            width: orb.size,
            height: orb.size,
            top: orb.top,
            left: orb.left,
            background: HUES[orb.hue],
            animationDuration: `${orb.duration}s`,
            animationDelay: `${orb.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

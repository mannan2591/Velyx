export function Footer() {
  return (
    <footer className="border-t border-white/[0.06] py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-sm text-muted md:flex-row">
        <p>© {new Date().getFullYear()} VelyxAI. Every conversation, held gently.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-cream">Privacy</a>
          <a href="#" className="hover:text-cream">Terms</a>
          <a href="#" className="hover:text-cream">Status</a>
        </div>
      </div>
    </footer>
  );
}

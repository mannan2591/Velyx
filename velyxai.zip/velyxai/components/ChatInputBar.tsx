"use client";

import * as React from "react";
import { Paperclip, Image as ImageIcon, Mic, ArrowUp } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatInputBarProps {
  value: string;
  onChange: (v: string) => void;
  onSend: () => void;
  onVoiceClick?: () => void;
  disabled?: boolean;
}

export function ChatInputBar({ value, onChange, onSend, onVoiceClick, disabled }: ChatInputBarProps) {
  const fileRef = React.useRef<HTMLInputElement>(null);
  const imageRef = React.useRef<HTMLInputElement>(null);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !disabled) onSend();
    }
  };

  return (
    <div className="glass-panel-strong flex items-end gap-2 rounded-2xl p-2.5">
      <input ref={fileRef} type="file" className="hidden" aria-label="Upload document" />
      <input ref={imageRef} type="file" accept="image/*" className="hidden" aria-label="Upload image" />

      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        className="rounded-lg p-2 text-muted hover:bg-white/5 hover:text-cream"
        aria-label="Attach file"
      >
        <Paperclip className="h-4.5 w-4.5" />
      </button>
      <button
        type="button"
        onClick={() => imageRef.current?.click()}
        className="rounded-lg p-2 text-muted hover:bg-white/5 hover:text-cream"
        aria-label="Attach image"
      >
        <ImageIcon className="h-4.5 w-4.5" />
      </button>

      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        rows={1}
        placeholder="Message VelyxAI..."
        className="max-h-40 flex-1 resize-none bg-transparent px-2 py-2 text-sm text-cream placeholder:text-muted/60 focus:outline-none"
      />

      <button
        type="button"
        onClick={onVoiceClick}
        className="rounded-lg p-2 text-muted hover:bg-white/5 hover:text-cream"
        aria-label="Voice input"
      >
        <Mic className="h-4.5 w-4.5" />
      </button>

      <button
        type="button"
        onClick={onSend}
        disabled={disabled || !value.trim()}
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-full transition-colors",
          value.trim() && !disabled
            ? "bg-violet-500 text-cream hover:bg-violet-400"
            : "bg-white/10 text-muted"
        )}
        aria-label="Send message"
      >
        <ArrowUp className="h-4 w-4" />
      </button>
    </div>
  );
}

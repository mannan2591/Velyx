import { cn } from "@/lib/utils";

export function Loader({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "h-4 w-4 animate-spin rounded-full border-2 border-violet-300/30 border-t-violet-300",
        className
      )}
      role="status"
      aria-label="Loading"
    />
  );
}

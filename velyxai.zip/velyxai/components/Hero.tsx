"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { AssistantAvatar } from "./AssistantAvatar";
import { GradientButton } from "./GradientButton";
import { ParticleBackground } from "./ParticleBackground";

export function Hero() {
  return (
    <section className="relative flex min-h-[92vh] flex-col items-center justify-center overflow-hidden px-6 text-center">
      <ParticleBackground count={10} />

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-8 rounded-full border border-white/10 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.2em] text-lavender/80"
      >
        Now with live voice presence
      </motion.p>

      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      >
        <AssistantAvatar size="xl" className="mb-10" />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-3xl font-display text-5xl leading-[1.05] text-cream md:text-7xl"
      >
        The Future of <span className="text-gradient-violet">AI Assistance</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="mt-6 max-w-xl text-balance text-lg text-muted"
      >
        A companion that remembers, speaks, and thinks alongside you — shaped
        to a personality only you define.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.45 }}
        className="mt-10 flex flex-wrap items-center justify-center gap-4"
      >
        <Link href="/chat">
          <GradientButton>Get Started</GradientButton>
        </Link>
        <Link href="/voice">
          <GradientButton variant="ghost">Try VelyxAI</GradientButton>
        </Link>
      </motion.div>
    </section>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Copy, RotateCcw, Pencil, Trash2, Check } from "lucide-react";
import { cn, formatTime } from "@/lib/utils";
import type { ChatMessage } from "@/types/chat";
import { AssistantAvatar } from "./AssistantAvatar";
import { TypingIndicator } from "./TypingAnimation";

interface MessageBubbleProps {
  message: ChatMessage;
  onRegenerate?: (id: string) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

export function MessageBubble({ message, onRegenerate, onEdit, onDelete }: MessageBubbleProps) {
  const [copied, setCopied] = React.useState(false);
  const isUser = message.role === "user";

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className={cn("group flex gap-3", isUser && "flex-row-reverse")}
    >
      {!isUser && <AssistantAvatar size="sm" className="mt-1 shrink-0" />}

      <div className={cn("flex max-w-[75%] flex-col", isUser && "items-end")}>
        <div
          className={cn(
            "rounded-2xl px-4 py-3 text-sm leading-relaxed",
            isUser
              ? "bg-violet-500/90 text-cream"
              : "glass-panel text-cream/95"
          )}
        >
          {message.pending ? (
            <TypingIndicator />
          ) : (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                code({ className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || "");
                  return match ? (
                    <SyntaxHighlighter
                      style={oneDark as any}
                      language={match[1]}
                      PreTag="div"
                      customStyle={{ borderRadius: 12, fontSize: "0.8rem", margin: "0.5rem 0" }}
                    >
                      {String(children).replace(/\n$/, "")}
                    </SyntaxHighlighter>
                  ) : (
                    <code className="rounded bg-white/10 px-1.5 py-0.5 text-xs" {...props}>
                      {children}
                    </code>
                  );
                },
              }}
            >
              {message.content}
            </ReactMarkdown>
          )}
        </div>

        <div className="mt-1 flex items-center gap-2 px-1">
          <span className="font-mono text-[11px] text-muted/70">
            {formatTime(new Date(message.createdAt))}
          </span>
          {!message.pending && (
            <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
              <button aria-label="Copy message" onClick={handleCopy} className="rounded p-1 text-muted hover:text-cream">
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
              {!isUser && onRegenerate && (
                <button aria-label="Regenerate response" onClick={() => onRegenerate(message.id)} className="rounded p-1 text-muted hover:text-cream">
                  <RotateCcw className="h-3.5 w-3.5" />
                </button>
              )}
              {isUser && onEdit && (
                <button aria-label="Edit message" onClick={() => onEdit(message.id)} className="rounded p-1 text-muted hover:text-cream">
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              )}
              {onDelete && (
                <button aria-label="Delete message" onClick={() => onDelete(message.id)} className="rounded p-1 text-muted hover:text-cream">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

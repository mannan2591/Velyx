"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GradientButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "solid" | "ghost";
}

export const GradientButton = React.forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ className, variant = "solid", children, ...props }, ref) => {
    const [pos, setPos] = React.useState({ x: 0, y: 0 });

    return (
      <motion.button
        ref={ref}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          setPos({ x: (e.clientX - rect.left - rect.width / 2) * 0.15, y: (e.clientY - rect.top - rect.height / 2) * 0.3 });
        }}
        onMouseLeave={() => setPos({ x: 0, y: 0 })}
        animate={{ x: pos.x, y: pos.y }}
        transition={{ type: "spring", stiffness: 200, damping: 15, mass: 0.4 }}
        className={cn(
          "relative inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium tracking-wide transition-shadow",
          variant === "solid" &&
            "bg-gradient-to-r from-violet-400 via-violet-500 to-violet-600 text-cream shadow-glow-violet hover:shadow-[0_0_70px_-8px_rgba(139,108,222,0.65)]",
          variant === "ghost" &&
            "border border-white/15 text-cream/90 glass-panel hover:border-white/30",
          className
        )}
        {...props}
      >
        {children}
      </motion.button>
    );
  }
);
GradientButton.displayName = "GradientButton";

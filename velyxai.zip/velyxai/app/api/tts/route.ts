import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/** Accepts { text, voice }, returns streamed audio for playback. */
export async function POST(req: Request) {
  const { text, voice = "alloy" } = await req.json();

  const speech = await client.audio.speech.create({
    model: "tts-1",
    voice,
    input: text,
  });

  const buffer = Buffer.from(await speech.arrayBuffer());
  return new Response(buffer, {
    headers: { "Content-Type": "audio/mpeg" },
  });
}

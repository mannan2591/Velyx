import { openai } from "@ai-sdk/openai";
import { streamText } from "ai";

export const runtime = "edge";

const SYSTEM_PROMPT = `You are VelyxAI, a warm, articulate, and precise personal assistant.
Keep responses focused and helpful. Use markdown and code blocks when useful.`;

export async function POST(req: Request) {
  const { messages } = await req.json();

  // OPENAI_API_KEY (or OPENAI_BASE_URL for any OpenAI-compatible provider)
  // must be set in the environment — never hardcode keys client-side.
  const result = streamText({
    model: openai(process.env.VELYXAI_MODEL ?? "gpt-4o-mini"),
    system: SYSTEM_PROMPT,
    messages,
    temperature: 0.7,
  });

  return result.toDataStreamResponse();
}

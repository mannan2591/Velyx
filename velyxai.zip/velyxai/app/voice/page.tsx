"use client";

import * as React from "react";
import { Mic, Square, Volume2 } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { AssistantAvatar } from "@/components/AssistantAvatar";
import { VoiceVisualizer } from "@/components/VoiceVisualizer";
import { GlassCard } from "@/components/GlassCard";
import { GradientButton } from "@/components/GradientButton";
import { useVoiceRecorder } from "@/hooks/useVoiceRecorder";
import type { VoiceProfile } from "@/types/voice";
import { cn } from "@/lib/utils";

const VOICE_PROFILES: VoiceProfile[] = [
  { id: "alloy", name: "Aria", style: "warm", description: "Warm, articulate, calm confidence" },
  { id: "verse", name: "Nova", style: "bright", description: "Bright, quick, upbeat energy" },
  { id: "sable", name: "Cove", style: "deep", description: "Deep, deliberate, grounded" },
];

export default function VoiceStudioPage() {
  const { status, levels, start, stop } = useVoiceRecorder();
  const [transcript, setTranscript] = React.useState("");
  const [selectedVoice, setSelectedVoice] = React.useState(VOICE_PROFILES[0].id);
  const isRecording = status === "recording";
  const amplitude = levels.reduce((a, b) => a + b, 0) / levels.length;

  const handleToggle = async () => {
    if (isRecording) {
      const blob = await stop();
      if (blob) {
        const form = new FormData();
        form.append("audio", blob, "recording.webm");
        try {
          const res = await fetch("/api/voice", { method: "POST", body: form });
          const data = await res.json();
          setTranscript(data.text ?? "");
        } catch {
          setTranscript("(Couldn't reach transcription service — check your API key.)");
        }
      }
    } else {
      setTranscript("");
      await start();
    }
  };

  return (
    <main className="min-h-screen">
      <Navbar />
      <section className="mx-auto flex max-w-3xl flex-col items-center px-6 py-16">
        <AssistantAvatar amplitude={isRecording ? amplitude : undefined} size="xl" className="mb-8" />

        <h1 className="font-display text-3xl text-cream">Voice Studio</h1>
        <p className="mt-2 text-center text-sm text-muted">
          Speak, and VelyxAI will transcribe and respond in the voice you choose below.
        </p>

        <GlassCard className="mt-10 w-full p-6">
          <VoiceVisualizer levels={levels} active={isRecording} />

          <div className="mt-4 flex justify-center">
            <button
              onClick={handleToggle}
              className={cn(
                "flex h-16 w-16 items-center justify-center rounded-full transition-colors",
                isRecording ? "bg-glow-rose bg-rose-300/80" : "bg-violet-500 hover:bg-violet-400"
              )}
              style={isRecording ? { backgroundColor: "#E7B8C9" } : undefined}
              aria-label={isRecording ? "Stop recording" : "Start recording"}
            >
              {isRecording ? <Square className="h-5 w-5 text-ground" /> : <Mic className="h-6 w-6 text-cream" />}
            </button>
          </div>

          <p className="mt-3 text-center font-mono text-xs uppercase tracking-wider text-muted">
            {status === "idle" && "Tap to speak"}
            {status === "recording" && "Listening..."}
            {status === "processing" && "Transcribing..."}
            {status === "error" && "Microphone unavailable"}
          </p>

          {transcript && (
            <div className="mt-6 rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-cream/90">
              {transcript}
            </div>
          )}
        </GlassCard>

        <div className="mt-8 w-full">
          <p className="mb-3 text-xs uppercase tracking-wider text-muted">Voice style</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {VOICE_PROFILES.map((v) => (
              <button
                key={v.id}
                onClick={() => setSelectedVoice(v.id)}
                className={cn(
                  "rounded-xl border p-4 text-left transition-colors",
                  selectedVoice === v.id
                    ? "border-violet-300/50 bg-violet-500/10"
                    : "border-white/10 hover:bg-white/5"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-cream">{v.name}</span>
                  <Volume2 className="h-3.5 w-3.5 text-muted" />
                </div>
                <p className="mt-1 text-xs text-muted">{v.description}</p>
              </button>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

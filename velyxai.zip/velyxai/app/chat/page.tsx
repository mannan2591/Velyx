"use client";

import * as React from "react";
import { Plus, MessageSquare } from "lucide-react";
import { useVelyxChat } from "@/hooks/useVelyxChat";
import { MessageBubble } from "@/components/MessageBubble";
import { ChatInputBar } from "@/components/ChatInputBar";
import { AssistantAvatar } from "@/components/AssistantAvatar";
import { GlassCard } from "@/components/GlassCard";

const SUGGESTED = [
  "Tell me about yourself",
  "What can you help me with?",
  "Draft a follow-up email",
  "Plan my week",
];

const RECENT_CHATS = ["Tell me about yourself", "Quarterly review prep", "New project"];

export default function ChatPage() {
  const { messages, input, setInput, handleSubmit, isLoading } = useVelyxChat();
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    handleSubmit(new Event("submit") as any);
  };

  return (
    <div className="flex h-screen bg-ground">
      {/* Sidebar */}
      <aside className="hidden w-64 flex-col border-r border-white/[0.06] p-4 md:flex">
        <div className="mb-6 flex items-center gap-2">
          <AssistantAvatar size="sm" />
          <div>
            <p className="text-sm font-medium text-cream">Lina</p>
            <p className="text-xs text-muted">Executive Assistant</p>
          </div>
        </div>
        <button className="mb-6 flex items-center justify-center gap-2 rounded-xl border border-white/10 py-2.5 text-sm text-cream hover:bg-white/5">
          <Plus className="h-4 w-4" /> New chat
        </button>
        <p className="mb-2 px-1 text-xs uppercase tracking-wider text-muted">Chats</p>
        <div className="flex flex-col gap-1">
          {RECENT_CHATS.map((c) => (
            <button
              key={c}
              className="flex items-center gap-2 rounded-lg px-2 py-2 text-left text-sm text-muted hover:bg-white/5 hover:text-cream"
            >
              <MessageSquare className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{c}</span>
            </button>
          ))}
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-white/[0.06] px-6 py-4">
          <AssistantAvatar size="sm" />
          <div>
            <p className="text-sm font-medium text-cream">Lina</p>
            <p className="text-xs text-muted">Online · Executive Assistant</p>
          </div>
        </header>

        <div ref={scrollRef} className="flex-1 space-y-5 overflow-y-auto px-6 py-6">
          {messages.length === 0 && (
            <div className="mx-auto flex max-w-md flex-col items-center pt-16 text-center">
              <AssistantAvatar size="lg" className="mb-6" />
              <h2 className="font-display text-2xl text-cream">Good to see you.</h2>
              <p className="mt-2 text-sm text-muted">
                Ask me anything, or start from one of these.
              </p>
              <div className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {SUGGESTED.map((s) => (
                  <button
                    key={s}
                    onClick={() => setInput(s)}
                    className="rounded-xl border border-white/10 px-4 py-2.5 text-sm text-cream/90 hover:bg-white/5"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => (
            <MessageBubble
              key={m.id}
              message={{
                id: m.id,
                role: m.role as "user" | "assistant",
                content: m.content,
                createdAt: new Date().toISOString(),
              }}
            />
          ))}

          {isLoading && (
            <MessageBubble
              message={{ id: "pending", role: "assistant", content: "", createdAt: new Date().toISOString(), pending: true }}
            />
          )}
        </div>

        <div className="border-t border-white/[0.06] p-4">
          <div className="mx-auto max-w-3xl">
            <ChatInputBar value={input} onChange={setInput} onSend={send} disabled={isLoading} />
            <p className="mt-2 text-center text-[11px] text-muted/60">
              VelyxAI can make mistakes. Verify anything important.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

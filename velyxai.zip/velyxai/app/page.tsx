import {
  Mic,
  Brain,
  ScanEye,
  FileText,
  Workflow,
  ListChecks,
  Calendar,
  Mail,
  Sparkles,
  Code2,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { FeatureCard } from "@/components/FeatureCard";

const FEATURES = [
  { icon: Mic, title: "Voice AI", description: "Speak naturally and hear a voice that matches the mood of the moment." },
  { icon: Brain, title: "Memory", description: "VelyxAI remembers context across sessions, so you never repeat yourself." },
  { icon: ScanEye, title: "Image Understanding", description: "Drop in a photo or screenshot and get a grounded, specific read on it." },
  { icon: FileText, title: "Document Analysis", description: "Long PDFs and reports, distilled into what actually matters to you." },
  { icon: Workflow, title: "Workflow Automation", description: "Chain steps together once, then let VelyxAI run the routine for you." },
  { icon: ListChecks, title: "Task Planning", description: "Turn a vague goal into an ordered plan with realistic checkpoints." },
  { icon: Calendar, title: "Calendar", description: "Reschedule, protect focus time, and get a daily brief without asking." },
  { icon: Mail, title: "Email Assistant", description: "Drafts that sound like you, triaged by what's actually urgent." },
  { icon: Sparkles, title: "Custom Personalities", description: "Tune tone, humor, and formality until it feels like your assistant." },
  { icon: Code2, title: "Developer API", description: "Bring VelyxAI's reasoning and voice into your own product." },
];

export default function LandingPage() {
  return (
    <main className="relative min-h-screen">
      <Navbar />
      <Hero />

      <section className="mx-auto max-w-6xl px-6 py-28">
        <div className="mb-14 max-w-xl">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-violet-300">Capabilities</p>
          <h2 className="mt-3 font-display text-3xl text-cream md:text-4xl">
            Everything a companion needs, nothing it doesn't.
          </h2>
        </div>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <FeatureCard key={f.title} index={i} {...f} />
          ))}
        </div>
      </section>

      <Footer />
    </main>
  );
}

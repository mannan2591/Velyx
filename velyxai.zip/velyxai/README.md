# VelyxAI

A premium AI assistant SaaS interface — landing page, streaming chat, and a
live Voice Studio — built on Next.js 15 / React 19 / TypeScript.

## Design language

- **Palette**: deep aubergine ground (`#160F1E`), violet signal color
  (`#8161CE`–`#9B7EDE`), lavender and cream surfaces, with a rose glow
  reserved only for the voice/presence orb.
- **Type**: Fraunces (display, editorial serif) + Manrope (body/UI) +
  JetBrains Mono (labels, timestamps, data).
- **Signature element**: "The Presence" — `components/AssistantAvatar.tsx`,
  a breathing gradient orb (not a literal face) that appears in the nav,
  the hero, chat header, and reacts live to microphone amplitude in Voice
  Studio. It's the one throughline across all three pages.

## What's included

```
app/
  page.tsx            landing
  chat/page.tsx        streaming chat UI
  voice/page.tsx        Voice Studio (record → transcribe → voice picker)
  api/chat/route.ts     Vercel AI SDK streaming route (edge)
  api/voice/route.ts    Whisper transcription route
  api/tts/route.ts      text-to-speech route
components/            Navbar, Footer, Hero, GlassCard, GradientButton,
                        ParticleBackground, FeatureCard, MessageBubble,
                        ChatInputBar, VoiceVisualizer, AssistantAvatar, ...
hooks/
  useVelyxChat.ts       wraps ai/react's useChat
  useVoiceRecorder.ts   mic capture + live Web Audio amplitude analysis
providers/              ThemeProvider (next-themes), QueryProvider
types/                  chat.ts, voice.ts
```

## Setup

```bash
npm install
cp .env.example .env.local   # add your OPENAI_API_KEY
npm run dev
```

Voice Studio needs the browser to grant microphone access, and both
`/api/voice` and `/api/chat` require `OPENAI_API_KEY` to be set — without it
the chat route will error and the transcript will show a fallback message.

## Scope note

This ships three pages fully wired (landing, chat, voice) plus the shared
component/hook/API layer they depend on. The remaining pages from the
original brief (create/customizer, settings, profile, pricing, login,
dashboard) aren't built yet — the structure here (GlassCard, GradientButton,
AssistantAvatar, providers) is meant to extend cleanly into them.

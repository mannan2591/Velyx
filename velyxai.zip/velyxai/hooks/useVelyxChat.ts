"use client";

import * as React from "react";
import { useChat } from "ai/react";

/**
 * Thin wrapper around Vercel AI SDK's useChat, pointed at our streaming
 * route. Kept separate so pages depend on `useVelyxChat`, not the SDK
 * directly — swapping providers later only touches this file and the route.
 */
export function useVelyxChat() {
  const chat = useChat({
    api: "/api/chat",
    onError: (err) => {
      console.error("VelyxAI chat error:", err);
    },
  });

  return chat;
}

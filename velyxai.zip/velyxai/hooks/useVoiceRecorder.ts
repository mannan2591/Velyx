"use client";

import * as React from "react";
import type { RecorderStatus } from "@/types/voice";

const BAR_COUNT = 28;

/**
 * Captures microphone audio, exposes live amplitude bars for the
 * VoiceVisualizer, and returns a recorded Blob on stop() for transcription.
 */
export function useVoiceRecorder() {
  const [status, setStatus] = React.useState<RecorderStatus>("idle");
  const [levels, setLevels] = React.useState<number[]>(Array(BAR_COUNT).fill(0));

  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const chunksRef = React.useRef<Blob[]>([]);
  const audioCtxRef = React.useRef<AudioContext | null>(null);
  const rafRef = React.useRef<number | null>(null);

  const stopVisualizer = React.useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    audioCtxRef.current?.close().catch(() => {});
  }, []);

  const start = React.useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        analyser.getByteFrequencyData(data);
        const step = Math.floor(data.length / BAR_COUNT);
        const next = Array.from({ length: BAR_COUNT }, (_, i) => data[i * step] / 255);
        setLevels(next);
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();

      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.start();
      mediaRecorderRef.current = recorder;
      setStatus("recording");
    } catch {
      setStatus("error");
    }
  }, []);

  const stop = React.useCallback((): Promise<Blob | null> => {
    return new Promise((resolve) => {
      const recorder = mediaRecorderRef.current;
      if (!recorder) return resolve(null);
      recorder.onstop = () => {
        stopVisualizer();
        setLevels(Array(BAR_COUNT).fill(0));
        setStatus("processing");
        resolve(new Blob(chunksRef.current, { type: "audio/webm" }));
      };
      recorder.stop();
      recorder.stream.getTracks().forEach((t) => t.stop());
    });
  }, [stopVisualizer]);

  const reset = React.useCallback(() => setStatus("idle"), []);

  React.useEffect(() => () => stopVisualizer(), [stopVisualizer]);

  return { status, levels, start, stop, reset };
}
